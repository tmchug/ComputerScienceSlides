import pygame
from tkinter import *

# improved rendering
import ctypes
from ctypes import windll

# importing custom
import customtkinter

# Other thing's
ctypes.windll.shcore.SetProcessDpiAwareness(True)
h = windll.user32.FindWindowA(b'Shell_TrayWnd', None)
windll.user32.ShowWindow(h, 1)

# Sounds
pygame.init()
def open_sound():
    pygame.mixer.music.load("sounds/click-open.wav")
    pygame.mixer.music.play()
def close_sound():
    pygame.mixer.music.load("sounds/click-close.wav")
    pygame.mixer.music.play()
def background_sound():
    pygame.mixer.music.load("sounds/thunder-effect.wav")
    pygame.mixer.music.play()

# Designing popup's for Credits
def credits_screen():
    global credits_screen
    credits_screen = Toplevel(main_screen)

    LSws = credits_screen.winfo_screenwidth()  # width of the screen
    LShs = credits_screen.winfo_screenheight()  # height of the screen

    LSw = 450  # width for the Tk root
    LSh = 400  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    LSx = (LSws / 2) - (LSw / 2) + 10
    LSy = (LShs / 2) - (LSh / 2) + 50

    credits_screen.overrideredirect(True)
    credits_screen.geometry('%dx%d+%d+%d' % (LSw, LSh, LSx, LSy))
    credits_screen.title("Credits")
    credits_screen.iconbitmap('icons/users-2.ico')
    open_sound()

    Label(credits_screen, text="Credits", width="300", height="5", font=("Calibri", 13)).pack()
    Label(text="").pack()

    Label(credits_screen, text="🙌\nThanks for taking a look at my project,\n here's the credits,\n\n"
                               "Scripter: Thomás M\n\n\n").pack()
    customtkinter.CTkButton(credits_screen,
                            text="Close",
                            text_color="#1B1B1B",
                            height=30, width=100,
                            corner_radius=50,
                            hover_color="#D7D7D7",
                            fg_color="#E4E3E2",
                            command=delete_credits_screen).pack()
    Label(credits_screen, text=" \n").pack()

    credits_screen.resizable(width=False, height=False)

# Designing popup's for Settings
def settings_screen():
    global settings_screen
    settings_screen = Toplevel(main_screen)

    LSws = settings_screen.winfo_screenwidth()  # width of the screen
    LShs = settings_screen.winfo_screenheight()  # height of the screen

    LSw = 450  # width for the Tk root
    LSh = 400  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    LSx = (LSws / 2) - (LSw / 2) + 10
    LSy = (LShs / 2) - (LSh / 2) + 50

    settings_screen.overrideredirect(True)
    settings_screen.geometry('%dx%d+%d+%d' % (LSw, LSh, LSx, LSy))
    settings_screen.title("Settings")
    settings_screen.iconbitmap('icons/users-2.ico')
    open_sound()

    Label(settings_screen, text="Settings", width="300", height="3", font=("Calibri", 13)).pack()
    Label(text="").pack()

    (Label(settings_screen, text="🚧\n More features soon.. \nNot much just a few customisations for\nthe sound...\n\n")
    .pack())

    def sound_volume():
        global off_label
        global on_label

        if check_sound.get() == 'on':
            pygame.mixer.music.set_volume(100)
            open_sound()
            on_label = Label(settings_screen, text='|🔈| Sound Haptics').place(x=100, y=281)

        elif check_sound.get() == 'off':
            pygame.mixer.music.set_volume(0)
            off_label = Label(settings_screen, text='|🔇| Sound Haptics').place(x=100, y=281)

    check_sound = customtkinter.StringVar(value="on")
    check_back_sound = customtkinter.StringVar(value="on")

    customtkinter.CTkSwitch(settings_screen,
                            text=' ',
                            variable=check_sound,
                            command=sound_volume,
                            button_hover_color='#D7D7D7',
                            progress_color='#3D424C',
                            fg_color='#E4E3E2',
                            button_color='#D7D7D7',
                            onvalue='on',
                            offvalue='off').place(x=235, y=226)

    Label(settings_screen, text='|🔈| Background Sound').place(x=100, y=341)
    customtkinter.CTkSwitch(settings_screen,
                            text=' ',
                            variable=check_back_sound,
                            button_hover_color='#D7D7D7',
                            progress_color='#3D424C',
                            fg_color='#E4E3E2',
                            button_color='#D7D7D7',
                            onvalue='on',
                            offvalue='off'
                            ).place(x=235, y=273)

    customtkinter.CTkButton(settings_screen,
                            text="Close",
                            text_color="#1B1B1B",
                            height=30, width=100,
                            corner_radius=50,
                            hover_color="#D7D7D7",
                            fg_color="#E4E3E2",
                            command=delete_settings_screen).pack()
    Label(settings_screen, text=" \n").pack()

    Label(settings_screen, text='|🔈| Sound Haptics').place(x=100, y=281)

    settings_screen.resizable(width=False, height=False)

# Designing popup's for Dice: Choice, Game
def dice_screen():
    global dice_screen
    dice_screen = Toplevel(main_screen)

    LSws = dice_screen.winfo_screenwidth()  # width of the screen
    LShs = dice_screen.winfo_screenheight()  # height of the screen

    LSw = 460  # width for the Tk root
    LSh = 440  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    LSx = (LSws / 2) - (LSw / 2) + 12
    LSy = (LShs / 2) - (LSh / 2) + 40

    dice_screen.overrideredirect(True)
    dice_screen.geometry('%dx%d+%d+%d' % (LSw, LSh, LSx, LSy))
    dice_screen.title("Roll a Die")
    dice_screen.iconbitmap('icons/users-2.ico')
    open_sound()

    Label(dice_screen, text="Roll a Die", width="300", height="6", font=("Calibri", 13)).pack()
    Label(text="").pack()

    # [WIP] Development FIX
    playFriends = PhotoImage(file='icons/person-standing.png')
    playBot = PhotoImage(file='icons/laptop.png')

    customtkinter.CTkButton(dice_screen,
                            image=playBot,
                            text='Play with a bot',
                            compound="top",
                            height=120,
                            width=30,
                            text_color="#1B1B1B",
                            corner_radius=20,
                            hover_color="#D7D7D7",
                            fg_color="#E4E3E2",
                            command=dice_bot_screen).place(x=25, y=125)

    customtkinter.CTkButton(dice_screen,
                            image=playFriends,
                            text='Play with a bff',
                            compound="top",
                            height=120,
                            width=30,
                            text_color="#1B1B1B",
                            corner_radius=20,
                            hover_color="#D7D7D7",
                            fg_color="#E4E3E2",
                            command=dice_friends_screen).place(x=210, y=125)

    customtkinter.CTkButton(dice_screen,
                            text="Back",
                            text_color="#1B1B1B",
                            height=30, width=100,
                            corner_radius=50,
                            hover_color="#D7D7D7",
                            fg_color="#E4E3E2",
                            command=delete_dice_screen).place(x=130, y=314)
    Label(dice_screen, text=" \n").pack()

    dice_screen.resizable(width=False, height=False)

# Choices
def dice_friends_screen():
    global dice_friends_screen
    dice_friends_screen = Toplevel(dice_screen)

    LSws = dice_friends_screen.winfo_screenwidth()  # width of the screen
    LShs = dice_friends_screen.winfo_screenheight()  # height of the screen

    LSw = 460  # width for the Tk root
    LSh = 440  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    LSx = (LSws / 2) - (LSw / 2) + 12
    LSy = (LShs / 2) - (LSh / 2) + 40

    dice_friends_screen.overrideredirect(True)
    dice_friends_screen.geometry('%dx%d+%d+%d' % (LSw, LSh, LSx, LSy))
    open_sound()

    Label(dice_friends_screen, text="Dice Roller", width="300", height="8", font=("Calibri", 13)).pack()
    Label(dice_friends_screen, text="").pack()

    customtkinter.CTkButton(dice_friends_screen,
                            text="Back",
                            text_color="#1B1B1B",
                            height=30, width=100,
                            corner_radius=50,
                            hover_color="#D7D7D7",
                            fg_color="#E4E3E2",
                            command=delete_dice_friends_screen).pack()
    Label(dice_friends_screen, text=" \n").pack()

    dice_friends_screen.resizable(width=False, height=False)
def dice_bot_screen():
    global dice_bot_screen
    dice_bot_screen = Toplevel(dice_screen)

    LSws = dice_bot_screen.winfo_screenwidth()  # width of the screen
    LShs = dice_bot_screen.winfo_screenheight()  # height of the screen

    LSw = 460  # width for the Tk root
    LSh = 440  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    LSx = (LSws / 2) - (LSw / 2) + 12
    LSy = (LShs / 2) - (LSh / 2) + 40

    dice_bot_screen.overrideredirect(True)
    dice_bot_screen.geometry('%dx%d+%d+%d' % (LSw, LSh, LSx, LSy))
    open_sound()

    Label(dice_bot_screen, text="Dice Roller Bot Edition", width="300", height="8", font=("Calibri", 13)).pack()
    Label(dice_bot_screen, text="").pack()

    customtkinter.CTkButton(dice_bot_screen,
                            text="Back",
                            text_color="#1B1B1B",
                            height=30, width=100,
                            corner_radius=50,
                            hover_color="#D7D7D7",
                            fg_color="#E4E3E2",
                            command=delete_dice_bot_screen).pack()
    Label(dice_bot_screen, text=" \n").pack()

    dice_bot_screen.resizable(width=False, height=False)

# 'Deleting popups'
def delete_settings_screen():
    close_sound()
    settings_screen.destroy()
def delete_credits_screen():
    close_sound()
    credits_screen.destroy()
def delete_dice_screen():
    close_sound()
    dice_screen.destroy()
def delete_dice_friends_screen():
    close_sound()
    dice_friends_screen.destroy()
def delete_dice_bot_screen():
    close_sound()
    dice_bot_screen.destroy()

# Designing Main(first) window
def options_menu():
    global main_screen

    main_screen = Tk()

    ws = main_screen.winfo_screenwidth()  # width of the screen
    hs = main_screen.winfo_screenheight()  # height of the screen

    w = 550  # width for the Tk root
    h = 450  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)

    main_screen.resizable(width=False, height=False)
    main_screen.geometry('%dx%d+%d+%d' % (w, h, x, y))
    main_screen.title("Account Login")
    main_screen.iconbitmap('icons/shapes.ico')
    pygame.mixer.music.load("sounds/atmosphere.wav")
    pygame.mixer.music.play()

    Label(text="Option's", width="300", height="8", font=("Calibri", 13)).pack()
    Label(text="").pack()
    customtkinter.CTkButton(main_screen,
                            text="Play",
                            text_color="#f0f0f0",
                            height=40, width=300,
                            corner_radius=50,
                            hover_color="#424852",
                            fg_color="#3d424c",
                            command=dice_screen,
                            ).pack()

    Label(text="").pack()
    customtkinter.CTkButton(main_screen,
                            text="Settings",
                            text_color="#f0f0f0",
                            height=40, width=300,
                            corner_radius=50,
                            hover_color="#424852",
                            fg_color="#3d424c",
                            command=settings_screen
                            ).pack()

    Label(text="").pack()
    customtkinter.CTkButton(main_screen,
                            text="Credits",
                            text_color="#1B1B1B",
                            height=30, width=100,
                            corner_radius=50,
                            hover_color="#D7D7D7",
                            fg_color="#E4E3E2",
                            command=credits_screen
                            ).pack()

    main_screen.mainloop()


options_menu()
