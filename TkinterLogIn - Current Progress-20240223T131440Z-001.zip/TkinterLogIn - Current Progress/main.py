# import modules
import pygame
import subprocess
import sqlite3
from tkinter import *

# improved rendering
import ctypes
from ctypes import windll

# importing custom
import customtkinter

# Other thing's
ctypes.windll.shcore.SetProcessDpiAwareness(True)
h = windll.user32.FindWindowA(b'Shell_TrayWnd', None)
windll.user32.ShowWindow(h, 0)

# Database
connection = sqlite3.connect('UserStore')
cursor = connection.cursor()

Data = """CREATE TABLE IF NOT EXISTS 
UserData(user TEXT, pass INTEGER)"""

cursor.execute(Data)
cursor.execute("SELECT * FROM userdata")

# Sounds
pygame.init()
def open_sound():
    pygame.mixer.music.load("sounds/click-open.wav")
    pygame.mixer.music.play()
def close_sound():
    pygame.mixer.music.load("sounds/click-close.wav")
    pygame.mixer.music.play()

# Designing window for registration
def register():
    global register_screen
    register_screen = Toplevel(main_screen)

    Rws = register_screen.winfo_screenwidth()  # width of the screen
    Rhs = register_screen.winfo_screenheight()  # height of the screen

    Rw = 350  # width for the Tk root
    Rh = 350  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    Rx = (Rws / 2) - (Rw / 2)
    Ry = (Rhs / 2) - (Rh / 2)

    register_screen.resizable(width=False, height=False)
    register_screen.geometry('%dx%d+%d+%d' % (Rw, Rh, Rx, Ry))
    register_screen.title('Register')
    register_screen.iconbitmap('icons/user-plus-2.ico')
    open_sound()

    # Globals
    global username
    global password
    global username_entry
    global password_entry
    global check_terms

    username = StringVar()
    password = StringVar()

    customtkinter.CTkLabel(register_screen,
                          text='',
                          height=1,
                          fg_color='transparent').pack()

    Label(register_screen, text='Please enter details below to register').pack()
    Label(register_screen, text=' ').pack()

    username_label = Label(register_screen, text='Username * ')
    username_label.pack()
    username_entry = customtkinter.CTkEntry(register_screen,
                                            text_color='#1B1B1B',
                                            height=23, width=125,
                                            corner_radius=50,
                                            border_width=0,
                                            fg_color='#E4E3E2',
                                            textvariable=username,)
    username_entry.pack()

    password_label = Label(register_screen, text='Password * ')
    password_label.pack()
    password_entry = customtkinter.CTkEntry(register_screen,
                                            text_color='#1B1B1B',
                                            height=23, width=125,
                                            corner_radius=50,
                                            border_width=0,
                                            fg_color='#E4E3E2',
                                            textvariable=password,
                                            show='*')
    password_entry.pack()

    Label(register_screen, text='').pack()

    # Terms box
    check_terms = customtkinter.StringVar(value='off')

    customtkinter.CTkCheckBox(register_screen,
                              text='My data will be stored * ',
                              variable=check_terms,
                              width=10, height=10,
                              text_color='#1B1B1B',
                              corner_radius=50,
                              border_width=11,
                              hover_color='#D7D7D7',
                              fg_color='#E4E3E2',
                              checkmark_color='#1B1B1B',
                              border_color='#E4E3E2',
                              onvalue='on',
                              offvalue='off').pack()

    customtkinter.CTkLabel(register_screen,
                             text='  ',
                             height=1,
                             fg_color='transparent').pack()

    customtkinter.CTkButton(register_screen,
                          text='Register',
                          text_color='#1B1B1B',
                          height=30, width=100,
                          corner_radius=50,
                          hover_color='#D7D7D7',
                          fg_color='#E4E3E2',
                          state='True',
                          command=register_user).pack()

# Designing window for login
def login():
    global login_screen
    login_screen = Toplevel(main_screen)

    Lws = login_screen.winfo_screenwidth()  # width of the screen
    Lhs = login_screen.winfo_screenheight()  # height of the screen

    Lw = 350  # width for the Tk root
    Lh = 250  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    Lx = (Lws / 2) - (Lw / 2)
    Ly = (Lhs / 2) - (Lh / 2)

    login_screen.resizable(width=False, height=False)
    login_screen.geometry('%dx%d+%d+%d' % (Lw, Lh, Lx, Ly))
    login_screen.title('Login')
    login_screen.iconbitmap('icons/users-2.ico')
    open_sound()

    # Globals
    global username_verify
    global password_verify
    global username_login_entry
    global password_login_entry

    # Logins Children
    Label(login_screen, text='Please enter details below to login').pack()
    Label(login_screen, text='').pack()

    username_verify = StringVar()
    password_verify = StringVar()

    Label(login_screen, text='Username * ').pack()

    username_login_entry = customtkinter.CTkEntry(login_screen,
                                                  text_color='#1B1B1B',
                                                  height=23, width=125,
                                                  corner_radius=50,
                                                  border_width=0,
                                                  fg_color='#E4E3E2',
                                                  textvariable=username_verify)
    username_login_entry.pack()

    Label(login_screen, text='Password * ').pack()

    password_login_entry = customtkinter.CTkEntry(login_screen,
                                                  text_color='#1B1B1B',
                                                  height=23, width=125,
                                                  corner_radius=50,
                                                  border_width=0,
                                                  fg_color='#E4E3E2',
                                                  textvariable=password_verify, show='*')
    password_login_entry.pack()

    Label(login_screen, text=' ').pack()
    customtkinter.CTkButton(login_screen,
                            text='Login',
                            text_color='#1B1B1B',
                            height=30, width=100,
                            corner_radius=50,
                            hover_color='#D7D7D7',
                            fg_color='#E4E3E2',
                            command=login_verify).pack()

# Implementing event on register button    ¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬
def register_user():
    username_info = username.get()
    password_info = password.get()
    check_info = check_terms.get()

    if len(username.get()) == 0 or len(password.get()) == 0 or check_info == 'off':
        register_error()

    elif len(username.get()) >= 3 and len(password.get()) >= 5 and check_info == 'on':
        connection.execute("INSERT INTO UserData VALUES (?, ?)", (username_info, password_info))
        connection.commit()

        results = cursor.fetchall()

        username_entry.delete(0, END)
        password_entry.delete(0, END)

        customtkinter.CTkLabel(register_screen,
                              text='',
                              height=0.2,
                              fg_color='transparent').pack()

        Label(register_screen,
              text='Registration Success',
              fg='#1B1B1B',
              font=('calibri', 11)
              ).pack()

        customtkinter.CTkLabel(register_screen,
                              text='',
                              height=1,
                              fg_color='transparent').pack()

        print(results)

# Implementing event on login button       ¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬
def login_verify():
    username1 = username_verify.get()
    password1 = password_verify.get()
    username_login_entry.delete(0, END)
    password_login_entry.delete(0, END)

    check = cursor.fetchall()

    if username1 in check:
        login_success()
    elif username1 in check and password1 in check == True:
        login_success()
    else:
        login_success()

# old version with the .txt file method [not at all secure]
    # list_of_files = os.listdir()
    # if username1 in list_of_files:
    #     file1 = open(username1, "r")
    #     verify = file1.read().splitlines()
    #     if password1 in verify:
    #         login_success()
    #     else:
    #         password_not_recognised()
    # else:
    #     user_not_found()


# Designing popup for login success
def login_success():
    global login_success_screen
    login_success_screen = Toplevel(login_screen)

    LSws = login_success_screen.winfo_screenwidth()  # width of the screen
    LShs = login_success_screen.winfo_screenheight()  # height of the screen

    LSw = 250  # width for the Tk root
    LSh = 100  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    LSx = (LSws / 2) - (LSw / 2)
    LSy = (LShs / 2) - (LSh / 2)

    login_success_screen.resizable(width=False, height=False)
    login_success_screen.geometry('%dx%d+%d+%d' % (LSw, LSh, LSx, LSy))
    login_success_screen.title('Success')
    login_success_screen.iconbitmap('icons/check-circle-2.ico')

    Label(login_success_screen, text='Login Success\n').pack()
    customtkinter.CTkButton(login_success_screen,
                            text='OK',
                            text_color='#1B1B1B',
                            height=30, width=100,
                            corner_radius=50,
                            hover_color='#D7D7D7',
                            fg_color='#E4E3E2',
                            command=delete_login_success).pack()
    Label(login_success_screen, text=' ').pack()

# Designing popup for login invalid password
def password_not_recognised():
    global password_not_recognised_screen
    password_not_recognised_screen = Toplevel()

    ws = password_not_recognised_screen.winfo_screenwidth()  # width of the screen
    hs = password_not_recognised_screen.winfo_screenheight()  # height of the screen

    w = 250  # width for the Tk root
    h = 100  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)

    password_not_recognised_screen.resizable(width=False, height=False)
    password_not_recognised_screen.geometry('%dx%d+%d+%d' % (w, h, x, y))
    password_not_recognised_screen.title('Error')
    password_not_recognised_screen.iconbitmap('icons/x-circle.ico')

    Label(password_not_recognised_screen, text='Invalid Password\n').pack()
    customtkinter.CTkButton(password_not_recognised_screen,
                            text='OK',
                            text_color='#1B1B1B',
                            height=30, width=100,
                            corner_radius=50,
                            hover_color='#D7D7D7',
                            fg_color='#E4E3E2',
                            command=delete_password_not_recognised).pack()
    Label(password_not_recognised_screen, text='').pack()

# Designing popup for user not found
def user_not_found():
    global user_not_found_screen
    user_not_found_screen = Toplevel(login_screen)
    ws = user_not_found_screen.winfo_screenwidth()  # width of the screen
    hs = user_not_found_screen.winfo_screenheight()  # height of the screen

    w = 250  # width for the Tk root
    h = 100  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)

    user_not_found_screen.resizable(width=False, height=False)
    user_not_found_screen.geometry('%dx%d+%d+%d' % (w, h, x, y))
    user_not_found_screen.title('Error')
    user_not_found_screen.iconbitmap('icons/x-circle.ico')

    Label(user_not_found_screen, text='User Not Found\n').pack()
    customtkinter.CTkButton(user_not_found_screen,
                            text='OK',
                            text_color='#1B1B1B',
                            height=30, width=100,
                            corner_radius=50,
                            hover_color='#D7D7D7',
                            fg_color='#E4E3E2',
                            command=delete_user_not_found_screen).pack()
    Label(user_not_found_screen, text=' ').pack()

# Designing popup's for Register
def register_error():
    global register_error_screen
    register_error_screen = Toplevel(register_screen)
    ws = register_error_screen.winfo_screenwidth()  # width of the screen
    hs = register_error_screen.winfo_screenheight()  # height of the screen

    w = 250  # width for the Tk root
    h = 100  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)

    register_error_screen.resizable(width=False, height=False)
    register_error_screen.geometry('%dx%d+%d+%d' % (w, h, x, y))
    register_error_screen.title('Error')
    register_error_screen.iconbitmap('icons/x-circle.ico')

    Label(register_error_screen, text='The form is not complete\n').pack()
    customtkinter.CTkButton(register_error_screen,
                            text='OK',
                            text_color='#1B1B1B',
                            height=30, width=100,
                            corner_radius=50,
                            hover_color='#D7D7D7',
                            fg_color='#E4E3E2',
                            command=delete_register_error).pack()
    Label(register_error_screen, text=' ').pack()


# 'Deleting popups'
def delete_login_success():
    close_sound()
    login_success_screen.destroy()
    windll.user32.ShowWindow(h, 1)
    subprocess.call(['python', 'game.py'])
def delete_password_not_recognised():
    close_sound()
    password_not_recognised_screen.destroy()
def delete_user_not_found_screen():
    close_sound()
    user_not_found_screen.destroy()
def delete_register_error():
    close_sound()
    register_error_screen.destroy()


# Designing Main(first) window
def main_account_screen():
    global main_screen
    main_screen = Tk()

    ws = main_screen.winfo_screenwidth()  # width of the screen
    hs = main_screen.winfo_screenheight()  # height of the screen

    w = 350  # width for the Tk root
    h = 250  # height for the Tk root

    # calculate x and y coordinates for the Tk root window
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)

    main_screen.resizable(width=False, height=False)
    main_screen.geometry('%dx%d+%d+%d' % (w, h, x, y))
    main_screen.title('Account Login')
    main_screen.iconbitmap('icons/panel-top-inactive.ico')

    Label(text='Select Your Choice', width='300', height='2', font=('Calibri', 13)).pack()
    Label(text='').pack()

    customtkinter.CTkButton(main_screen,
                            text='Login',
                            text_color='#1B1B1B',
                            height=40, width=200,
                            corner_radius=50,
                            hover_color='#D7D7D7',
                            fg_color='#E4E3E2',

                            command=login).pack()
    Label(text="").pack()

    customtkinter.CTkButton(main_screen,
                            text='Register',
                            text_color='#1B1B1B',
                            height=40, width=200,
                            corner_radius=50,
                            hover_color='#D7D7D7',
                            fg_color='#E4E3E2',
                            command=register).pack()

    main_screen.mainloop()


main_account_screen()
